package assign3.lexer ;

public class Tag {

    public final static int FALSE = 262 ;
    public final static int ID    = 264 ;
    public final static int NUM   = 270 ;
    public final static int TRUE  = 274 ;
    public final static int BASIC = 257;
}
